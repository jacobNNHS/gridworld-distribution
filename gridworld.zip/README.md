# GridWorld Distribution Code

This is the starter code for the GridWorld assignment.

## Files Included

- `gridworld.c` - Main program file with function stubs you need to implement
- `Makefile` - Build configuration for easy compilation

## Getting Started

1. Read through `gridworld.c` to understand the program structure
2. Implement the TODO functions one at a time
3. Test each function as you go

## Compilation

To compile your program, simply run:

```bash
make
```

This will create an executable called `gridworld`.

## Running

To run your program:

```bash
./gridworld
```

## Testing Your Implementation

Start by implementing functions in this order:

1. `init_grid()` - Simplest function, just fill with '.'
2. `display_grid()` - Lets you see what's happening
3. `place_entity()` - Core functionality
4. `list_entities()` - Helps debug placement
5. `move_entity()` - More complex logic
6. `count_neighbors()` - Good practice with 2D array boundaries
7. `remove_entity()` - Final piece

### Sample Test Session

```
$ ./gridworld
Welcome to GridWorld!
Type 'help' for a list of commands.

Enter command: display
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .

Enter command: place P 5 5
Placed P at (5, 5)

Enter command: place T 5 6
Placed T at (5, 6)

Enter command: display
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . P T . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .

Enter command: list
P at (5, 5)
T at (5, 6)

Enter command: move 5 5 right
Moved entity from (5, 5)

Enter command: display
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . P T . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
. . . . . . . . . .
```

## Tips

- Use `printf()` statements liberally while debugging
- Test boundary cases (corners, edges)
- Test invalid inputs
- Make sure to check array bounds before accessing elements
- Remember: `grid[row][col]` - row comes first!

## Cleaning Up

To remove compiled files:

```bash
make clean
```

Good luck!
